import GeometryGame from './GeometryGame'
import './index.css'

function App() {
  return <GeometryGame />
}

export default App
